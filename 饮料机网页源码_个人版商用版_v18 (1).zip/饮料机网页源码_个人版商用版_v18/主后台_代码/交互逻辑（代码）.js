
(function(){
  "use strict";

  var KEY = "drink_personal_v1";
  /* 与「用户端 · 小程序」共用的键：四格原料 / 用户端调配历史 */
  var SHARED_KEY = "four_slot_storage_v1";
  var USER_HIST_KEY = "dm_personal_hist_v1";
  function sharedSlots(){
    try{ var o = JSON.parse(localStorage.getItem(SHARED_KEY)||"{}"); return (o && typeof o === "object") ? o : {}; }catch(e){ return {}; }
  }
  function writeSharedSlots(){
    try{
      var o = sharedSlots();
      SLOTS.forEach(function(s){ o[s.k.toLowerCase()] = DB.slots[s.k] || ""; });
      localStorage.setItem(SHARED_KEY, JSON.stringify(o));
    }catch(e){ /* 写不进就算了 */ }
  }
  function userHist(){
    try{ var a = JSON.parse(localStorage.getItem(USER_HIST_KEY)||"[]"); return Array.isArray(a) ? a : []; }catch(e){ return []; }
  }
  var SLOTS = [
    { k:"X1Y1", no:"1 号格", pos:"左上" },
    { k:"X1Y2", no:"2 号格", pos:"左下" },
    { k:"X2Y1", no:"3 号格", pos:"右上" },
    { k:"X2Y2", no:"4 号格", pos:"右下" }
  ];

  var DB = {
    slots:{ X1Y1:"", X1Y2:"", X2Y1:"", X2Y2:"" },
    prefs:[], bans:[], logs:[], chat:[], history:[],
    caps:{ "东方树叶":0, "水溶 C100":0, "橙汁":0, "牛奶":0 },   /* 原料容量（杯） */
    users:[], orders:[], curUser:""                                /* 用户记录 / 点单（接收数据） */
  };

  /* 4 款固定配方（用户提供的固定配方） */
  var RECIPES = [
    { name:"茶韵舒润饮", parts:"东方树叶 2 份 + 牛奶 2 份", code:"tea 2 + milk 2", need:[["东方树叶",2],["牛奶",2]] },
    { name:"橙风舒沁饮", parts:"东方树叶 2 份 + 水溶 C100 2 份", code:"tea 2 + c 2", need:[["东方树叶",2],["水溶 C100",2]] },
    { name:"橙柔云翠饮", parts:"东方树叶 2 份 + 橙汁 2 份", code:"tea 2 + orange 2", need:[["东方树叶",2],["橙汁",2]] },
    { name:"橙鲜醒力饮", parts:"水溶 C100 2 份 + 橙汁 2 份", code:"c 2 + orange 2", need:[["水溶 C100",2],["橙汁",2]] }
  ];

  /* 4 种原料（机器编码 → 原料名） */
  var RAW = [
    { name:"东方树叶", code:"tea" },
    { name:"水溶 C100", code:"c" },
    { name:"橙汁", code:"orange" },
    { name:"牛奶", code:"milk" }
  ];

  function load(){
    try{
      var raw = localStorage.getItem(KEY);
      if(raw){
        var o = JSON.parse(raw);
        if(o && typeof o === "object"){
          if(o.slots) DB.slots = { X1Y1:o.slots.X1Y1||"", X1Y2:o.slots.X1Y2||"", X2Y1:o.slots.X2Y1||"", X2Y2:o.slots.X2Y2||"" };
          if(Array.isArray(o.prefs)) DB.prefs = o.prefs;
          if(Array.isArray(o.bans)) DB.bans = o.bans;
          if(Array.isArray(o.logs)) DB.logs = o.logs;
          if(Array.isArray(o.chat)) DB.chat = o.chat;
          if(Array.isArray(o.history)) DB.history = o.history;
          if(o.caps && typeof o.caps === "object") DB.caps = o.caps;
          if(Array.isArray(o.users)) DB.users = o.users;
          if(Array.isArray(o.orders)) DB.orders = o.orders;
          if(typeof o.curUser === "string") DB.curUser = o.curUser;
        }
      }
    }catch(e){ /* 读不到就用空数据 */ }
    /* 四格原料以「用户端 · 小程序」那份为准；那边还没有就先把这个页面的推过去 */
    try{
      if(localStorage.getItem(SHARED_KEY) !== null){
        var sh = sharedSlots();
        SLOTS.forEach(function(s){ DB.slots[s.k] = (sh[s.k.toLowerCase()]||"").trim(); });
      }else{
        writeSharedSlots();
      }
    }catch(e){ /* 共享读写出问题不影响本页 */ }
    RAW.forEach(function(r){
      var v = Number(DB.caps[r.name]);
      DB.caps[r.name] = (isNaN(v) || v < 0) ? 0 : v;
    });
  }
  function save(){
    try{ localStorage.setItem(KEY, JSON.stringify(DB)); }catch(e){ /* 写不进就算了 */ }
    writeSharedSlots();
  }

  function now(){
    var d = new Date();
    function p(n){ return (n<10?"0":"")+n; }
    return (d.getMonth()+1)+"-"+p(d.getDate())+" "+p(d.getHours())+":"+p(d.getMinutes());
  }
  function esc(s){
    return String(s==null?"":s).replace(/[&<>"']/g, function(c){
      return ({ "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;" })[c];
    });
  }
  function slotByNo(n){ return SLOTS[n-1] || null; }

  /* ---------------- 四个格子 ---------------- */
  function renderSlots(){
    var box = document.getElementById("slot-box");
    if(!box) return;
    box.innerHTML = SLOTS.map(function(s){
      var v = DB.slots[s.k] || "";
      return '<div class="slot'+(v?" filled":"")+'">'+
        '<span class="dot"></span>'+
        '<div class="no">'+esc(s.no)+' · '+esc(s.pos)+'</div>'+
        '<div class="val'+(v?"":" empty")+'">'+(v?esc(v):"空")+'</div>'+
        '<div class="pos">'+(v?"已放入":"还没放东西")+'</div>'+
      '</div>';
    }).join("");
  }

  function renderSlotEdit(){
    var box = document.getElementById("slot-edit");
    if(!box) return;
    box.innerHTML = SLOTS.map(function(s){
      var v = DB.slots[s.k] || "";
      return '<div class="row">'+
        '<div class="main"><div class="t">'+esc(s.no)+' · '+esc(s.pos)+'</div>'+
        '<div class="d">格子坐标 '+esc(s.k)+'</div></div>'+
        '<input class="slot-input" type="text" data-slot="'+esc(s.k)+'" value="'+esc(v)+'" placeholder="放什么？">'+
        '<button class="btn sm" type="button" data-save="'+esc(s.k)+'">保存</button>'+
        '<button class="btn ghost sm" type="button" data-clear="'+esc(s.k)+'">清空</button>'+
      '</div>';
    }).join("");
  }

  /* ---------------- 偏好 / 忌口 ---------------- */
  function renderPrefs(){
    var box = document.getElementById("pref-list");
    if(!box) return;
    if(!DB.prefs.length){
      box.innerHTML = '<div class="empty">还没记偏好。在下面直接加，比如「甜度 = 少糖」。</div>';
      return;
    }
    box.innerHTML = DB.prefs.map(function(p,i){
      return '<div class="row">'+
        '<div class="main"><div class="t">'+esc(p.key)+'：'+esc(p.value)+'</div>'+
        '<div class="d">来源：'+esc(p.from||"手动")+' · '+esc(p.time||"")+'</div></div>'+
        '<span class="pill">偏好</span>'+
        '<button class="btn ghost sm" type="button" data-pref-edit="'+i+'">改</button>'+
        '<button class="btn danger sm" type="button" data-pref-del="'+i+'">删</button>'+
      '</div>';
    }).join("");
  }

  function renderBans(){
    var box = document.getElementById("ban-list");
    if(!box) return;
    if(!DB.bans.length){
      box.innerHTML = '<div class="empty">还没记忌口。在下面直接加，比如「香菜」。</div>';
      return;
    }
    box.innerHTML = DB.bans.map(function(b,i){
      return '<div class="row">'+
        '<div class="main"><div class="t">'+esc(b.value)+'</div>'+
        '<div class="d">'+esc(b.kind)+' · 来源：'+esc(b.from||"手动")+' · '+esc(b.time||"")+'</div></div>'+
        '<span class="pill bad">避开</span>'+
        '<button class="btn ghost sm" type="button" data-ban-edit="'+i+'">改</button>'+
        '<button class="btn danger sm" type="button" data-ban-del="'+i+'">删</button>'+
      '</div>';
    }).join("");
  }

  /* ---------------- 固定配方 / 调配历史 / 原料 ---------------- */
  function renderRecipes(){
    var box = document.getElementById("recipe-list");
    if(!box) return;
    box.innerHTML = RECIPES.map(function(r,i){
      return '<div class="row">'+
        '<div class="main"><div class="t">'+esc(r.name)+'</div>'+
        '<div class="d">'+esc(r.parts)+' · '+esc(r.code)+' · 合计 4 份</div></div>'+
        '<button class="btn sm" type="button" data-brew="'+i+'">配一杯</button>'+
        '</div>';
    }).join("");
  }

  function renderHistory(){
    var box = document.getElementById("hist-list");
    var cnt = document.getElementById("hist-count");
    var mine = DB.history.map(function(h){
      return { name:h.name, parts:h.parts, time:h.time, mine:true };
    });
    var theirs = userHist().map(function(h){
      var d = h.settings || {};
      var bits = [];
      if(typeof d.sugar === "number") bits.push("糖 " + d.sugar);
      if(typeof d.milk === "number" && d.milk) bits.push("奶 " + d.milk);
      if(typeof d.orange === "number" && d.orange) bits.push("橙 " + d.orange);
      if(d.temp) bits.push(d.temp === "hot" ? "热" : "冷");
      var t = "";
      try{ t = h.ts ? new Date(h.ts).toLocaleString("zh-CN",{hour12:false}) : ""; }catch(e){}
      return { name:(h.name || "专属调配"), parts:(bits.join(" · ") || "用户端出的杯"), time:t, mine:false };
    });
    var all = mine.concat(theirs);
    if(cnt) cnt.textContent = "共 " + all.length + " 杯" + (theirs.length ? "（含用户端 " + theirs.length + " 杯）" : "");
    if(!box) return;
    if(!all.length){
      box.innerHTML = '<div class="empty">还没出过杯。用户端小程序里出的杯会出现在这儿，配过之后能「再来一杯」。</div>';
      return;
    }
    box.innerHTML = all.map(function(h){
      return '<div class="row">'+
        '<div class="main"><div class="t">'+esc(h.name)+'</div>'+
        '<div class="d">'+esc(h.parts)+(h.time ? ' · '+esc(h.time) : '')+'</div></div>'+
        (h.mine
          ? '<button class="btn ghost sm" type="button" data-again="'+esc(h.name)+'">再来一杯</button>'
          : '<span class="pill">用户端</span>')+
        '</div>';
    }).join("");
  }

  /* 用量：一杯 = 4 份，1 份 = 单杯总量的 25% → 每份记 0.25 杯 */
  function rawUsage(){
    var u = {};
    RAW.forEach(function(r){ u[r.name] = 0; });
    DB.history.forEach(function(h){
      (h.need||[]).forEach(function(p){ if(u[p[0]] !== undefined) u[p[0]] += p[1] * 0.25; });
    });
    /* 用户端（手机端）出的杯：用到的原料每种按 2 份计 */
    userHist().forEach(function(h){
      var ing = h.ingredients || {};
      RAW.forEach(function(r){ if(ing[r.code]) u[r.name] += 0.5; });
    });
    return u;
  }
  function stockList(){
    var used = rawUsage();
    return RAW.map(function(r){
      var cap = Number(DB.caps[r.name] || 0);
      var u = used[r.name] || 0;
      var remain = cap > 0 ? Math.max(0, cap - u) : 0;
      var pct = cap > 0 ? Math.round(remain / cap * 100) : null;
      var level = pct === null ? "" : (pct < 10 ? "bad" : (pct < 30 ? "warn" : "ok"));
      return { name:r.name, code:r.code, cap:cap, used:u, remain:remain, pct:pct, level:level };
    });
  }
  function renderRaw(){
    var box = document.getElementById("raw-list");
    if(!box) return;
    var st = stockList();
    var maxUse = 0, topN = 0;
    st.forEach(function(x){ if(x.used > maxUse) maxUse = x.used; });
    st.forEach(function(x){ if(maxUse > 0 && x.used === maxUse) topN++; });
    box.innerHTML = st.map(function(x){
      var capTxt = x.cap > 0 ? ("容量 " + x.cap + " 杯") : "容量待填";
      var pctTxt = x.pct === null ? "剩余待算" : ("剩 " + x.remain.toFixed(1) + " 杯（" + x.pct + "%）");
      var lamp = x.level === "bad" ? '<span class="pill bad">红灯 · 快没了</span>'
               : (x.level === "warn" ? '<span class="pill warn">黄灯 · 该补了</span>'
               : (x.level === "ok" ? '<span class="pill">充足</span>' : '<span class="pill">待填容量</span>'));
      var top = (maxUse > 0 && x.used === maxUse && topN === 1) ? '<span class="pill">用得最多</span>' : '';
      var w = x.pct === null ? 0 : x.pct;
      var cls = x.level === "bad" ? "bad" : (x.level === "warn" ? "warn" : "");
      return '<div class="row">'+
        '<div class="main"><div class="t">'+esc(x.name)+' · '+esc(x.code)+'</div>'+
        '<div class="d">'+esc(capTxt)+' · 已用 '+x.used.toFixed(1)+' 杯 · '+esc(pctTxt)+'</div>'+
        '<div class="bar"><i class="'+cls+'" style="width:'+w+'%"></i></div></div>'+
        top + lamp +
        '<input class="cap-input" type="number" min="0" step="1" data-cap="'+esc(x.name)+'" value="'+(x.cap>0?x.cap:"")+'" placeholder="容量">'+
        '<button class="btn ghost sm" type="button" data-capsave="'+esc(x.name)+'">存</button>'+
      '</div>';
    }).join("");
  }

  /* ---------------- 用户记录 / 用户群体 / 点单 / 数据交互 ---------------- */
  function pad2(n){ return (n<10?"0":"")+n; }
  function monthKey(ts){
    var d = ts ? new Date(ts) : new Date();
    if(isNaN(d.getTime())) d = new Date();
    return d.getFullYear() + "-" + pad2(d.getMonth()+1);
  }
  function stamp(ts){
    var d = ts ? new Date(ts) : new Date();
    if(isNaN(d.getTime())) return "";
    return monthKey(ts) + "-" + pad2(d.getDate()) + " " + pad2(d.getHours()) + ":" + pad2(d.getMinutes());
  }
  function userName(id){
    for(var i=0;i<DB.users.length;i++){
      if(DB.users[i].id === id) return DB.users[i].name || DB.users[i].acc || DB.users[i].id;
    }
    return id || "未指定";
  }
  function nextUserId(){
    var max = 0;
    DB.users.forEach(function(u){
      var m = /^U(\d+)$/.exec(u.id || "");
      if(m && parseInt(m[1],10) > max) max = parseInt(m[1],10);
    });
    var n = max + 1;
    return "U" + (n<10 ? ("00"+n) : (n<100 ? ("0"+n) : (""+n)));
  }
  function renderUsers(){
    var box = document.getElementById("user-list");
    var sel = document.getElementById("order-user");
    if(sel){
      sel.innerHTML = DB.users.length
        ? DB.users.map(function(u){
            return '<option value="'+esc(u.id)+'"'+(u.id===DB.curUser?" selected":"")+'>'+esc(u.id+" "+(u.name||u.acc||""))+'</option>';
          }).join("")
        : '<option value="">还没建用户</option>';
    }
    if(!box) return;
    if(!DB.users.length){
      box.innerHTML = '<div class="empty">还没建用户。下面填账号（或声纹）建一个，系统自动给编号 <b>U001</b>。</div>';
      return;
    }
    box.innerHTML = DB.users.map(function(u){
      var cur = u.id === DB.curUser;
      return '<div class="row">'+
        '<div class="main"><div class="t">'+esc(u.id)+' · '+esc(u.name||"未填称呼")+(cur?' <span class="pill">当前</span>':'')+'</div>'+
        '<div class="d">账号：'+esc(u.acc||"—")+' · 声纹：'+esc(u.voice||"—")+' · 建档 '+esc(u.created||"")+'</div></div>'+
        (cur ? "" : '<button class="btn ghost sm" type="button" data-userset="'+esc(u.id)+'">设为当前</button>')+
        '<button class="btn danger sm" type="button" data-userdel="'+esc(u.id)+'">删</button>'+
      '</div>';
    }).join("");
  }
  function renderGroup(){
    var sel = document.getElementById("group-month");
    var box = document.getElementById("group-stats");
    var months = [], i;
    for(i=0;i<6;i++){
      var d = new Date();
      d.setDate(1);
      d.setMonth(d.getMonth()-i);
      months.push(d.getFullYear()+"-"+pad2(d.getMonth()+1));
    }
    if(sel && !sel.options.length){
      sel.innerHTML = months.map(function(x){ return '<option value="'+x+'">'+x+'</option>'; }).join("");
      sel.value = months[0];
    }
    if(!box) return;
    var m = (sel && sel.value) ? sel.value : months[0];
    var total = DB.users.length;
    var newU = DB.users.filter(function(u){ return monthKey(u.createdTs) === m; }).length;
    var orders = DB.orders.filter(function(o){ return monthKey(o.ts) === m; });
    var byUser = {};
    orders.forEach(function(o){ byUser[o.user] = (byUser[o.user]||0)+1; });
    var activeN = Object.keys(byUser).length;
    var topId = "", topN = 0;
    Object.keys(byUser).forEach(function(k){ if(byUser[k] > topN){ topN = byUser[k]; topId = k; } });
    box.innerHTML = [
      ["用户总数", total + " 人", "建档在册"],
      ["活跃用户数", activeN + " 人", "本月有点单"],
      ["新增用户数", newU + " 人", "本月建档"],
      ["用户销冠", topId ? userName(topId) : "—", topId ? (topN + " 单") : "本月还没点单"]
    ].map(function(x){
      return '<div class="stat"><div class="k">'+esc(x[0])+'</div><div class="v">'+esc(x[1])+'</div><div class="s">'+esc(x[2])+'</div></div>';
    }).join("");
  }
  function renderOrders(){
    var box = document.getElementById("order-list");
    var cnt = document.getElementById("order-count");
    var mine = DB.orders.map(function(o){
      return { user:userName(o.user), drink:o.drink||"—", detail:o.detail||"", time:o.time||"", from:o.from||"手录" };
    });
    var theirs = userHist().map(function(h){
      var d = h.settings || {}, bits = [];
      if(typeof d.sugar === "number") bits.push("糖 "+d.sugar);
      if(d.temp) bits.push(d.temp === "hot" ? "热" : "冷");
      return {
        user:"手机端",
        drink:(h.name||"专属调配") + (bits.length ? "（"+bits.join(" · ")+"）" : ""),
        detail:h.desc||"",
        time:stamp(h.ts),
        from:"手机端"
      };
    });
    var all = mine.concat(theirs);
    if(cnt) cnt.textContent = "共 " + all.length + " 单" + (theirs.length ? "（含手机端 " + theirs.length + " 单）" : "");
    if(!box) return;
    if(!all.length){
      box.innerHTML = '<div class="empty">还没有点单记录。手机端传回、或下面手录一条，就出现在这儿。</div>';
      return;
    }
    box.innerHTML = all.slice(0,60).map(function(o){
      return '<div class="row">'+
        '<div class="main"><div class="t">'+esc(o.user)+' · '+esc(o.drink)+'</div>'+
        '<div class="d">'+esc(o.detail ? (o.detail + " · ") : "")+esc(o.time)+'</div></div>'+
        '<span class="pill">'+esc(o.from)+'</span>'+
      '</div>';
    }).join("");
  }
  function brew(i){
    var r = RECIPES[i];
    if(!r) return;
    DB.history.unshift({ name:r.name, parts:r.parts, time:now(), need:r.need });
    if(DB.history.length > 200) DB.history = DB.history.slice(0,200);
    addLog("调配", "配了一杯「"+r.name+"」（"+r.parts+"）", "手动");
    pushChat("me", "来一杯" + r.name);
    pushChat("bot", "好，按配方配「"+r.name+"」：" + r.parts + "。已经记进调配历史，下次点「再来一杯」就行。");
    save(); renderHistory(); renderRaw(); renderLogs(); renderChat();
  }

  /* ---------------- 记录 ---------------- */
  function addLog(action, content, from){
    DB.logs.unshift({ time:now(), action:action, content:content, from:from||"手动" });
    if(DB.logs.length > 200) DB.logs = DB.logs.slice(0,200);
  }
  function renderLogs(){
    var box = document.getElementById("log-list");
    var cnt = document.getElementById("log-count");
    if(cnt) cnt.textContent = "共 " + DB.logs.length + " 条";
    if(!box) return;
    if(!DB.logs.length){
      box.innerHTML = '<div class="empty">还没有改动记录。改偏好、加忌口、记点单、改原料容量，都会自动记一条。</div>';
      return;
    }
    box.innerHTML = DB.logs.map(function(l){
      var cls = l.action==="取料" ? "warn" : (l.action==="忌口" ? "bad" : "");
      return '<div class="row">'+
        '<div class="main"><div class="t">'+esc(l.content)+'</div>'+
        '<div class="d">'+esc(l.time)+' · 来源：'+esc(l.from)+'</div></div>'+
        '<span class="pill '+cls+'">'+esc(l.action)+'</span>'+
      '</div>';
    }).join("");
  }

  /* ---------------- 对话 ---------------- */
  function renderChat(){
    var box = document.getElementById("chat-box");
    if(!box) return;
    if(!DB.chat.length){
      box.innerHTML = '<div class="bubble bot"><span class="who">饮料机</span>你好，我是你这台机器的记性。'+
        '想放料就说「1 号格子加可乐」，爱喝什么、忌什么口也直接说，我都给你记着。</div>';
      return;
    }
    box.innerHTML = DB.chat.slice(-40).map(function(m){
      var me = m.role === "me";
      return '<div class="bubble '+(me?"me":"bot")+'"><span class="who">'+(me?"我":"饮料机")+'</span>'+esc(m.text)+'</div>';
    }).join("");
    box.scrollTop = box.scrollHeight;
  }
  function pushChat(role, text){
    DB.chat.push({ role:role, text:text, time:now() });
    if(DB.chat.length > 200) DB.chat = DB.chat.slice(-200);
  }

  /* ---------------- 听懂人话 ---------------- */
  var CN_NUM = { "一":1, "二":2, "两":2, "三":3, "四":4, "1":1, "2":2, "3":3, "4":4 };

  function pickSlot(text){
    var m = text.match(/([一二两三四1234])\s*号?\s*(?:格|格子|盒子|仓|盒)/);
    if(m) return CN_NUM[m[1]] || 0;
    if(/左上/.test(text)) return 1;
    if(/左下/.test(text)) return 2;
    if(/右上/.test(text)) return 3;
    if(/右下/.test(text)) return 4;
    return 0;
  }

  function cleanStuff(s){
    return String(s||"")
      .replace(/[。！!，,、；;～~]+$/g,"")
      .replace(/^(放|装|加|倒|换成|换|来|要|弄)/g,"")
      .replace(/(吧|谢谢|就行|可以了|好嘛|好吗|了)$/g,"")
      .trim();
  }

  function statusText(){
    var parts = SLOTS.map(function(s){
      var v = DB.slots[s.k];
      return s.no + "：" + (v ? v : "空");
    });
    return parts.join("，") + "。";
  }

  function parse(text){
    var t = text.trim();
    var slotNo;

    /* 1. 问现状 */
    if(/(现在|目前).*(放|装|有).*(什么|啥|哪些)|剩多少|还剩|有什么|都放了|现状|四个格|查看.*格/.test(t)){
      return "现在四个格子是这样 —— " + statusText();
    }

    /* 2. 忌口 / 过敏（先判，因为有"不"） */
    if(/(过敏|忌口|不吃|不能吃|吃不了|喝不了|别放|不要放|别加|不要加|禁)/.test(t)){
      var bv = t
        .replace(/^(我|咱|这边)?\s*(对)?/, "")
        .replace(/(过敏|忌口|不吃|不能吃|吃不了|喝不了|别放|不要放|别加|不要加|禁)/g, " ")
        .replace(/[。！!，,、；;]+/g, " ")
        .trim();
      bv = cleanStuff(bv.split(/\s+/).filter(Boolean).slice(-1)[0] || "");
      if(bv && bv.length <= 12){
        var kind = /过敏/.test(t) ? "过敏原" : (/孕|糖尿病|高血压|小孩|儿童|老人/.test(t) ? "特殊人群" : "忌口");
        DB.bans.unshift({ value:bv, kind:kind, from:"说话", time:now() });
        addLog("忌口", "记下忌口：" + bv + "（" + kind + "）", "说话");
        save(); renderBans(); renderLogs();
        return "记下了 —— 「" + bv + "」以后都给你避开，做单的时候不会放进去。";
      }
      return "听出来是忌口，但没听清是什么。你直接说「我不吃香菜」这样就行。";
    }

    /* 3. 偏好 */
    if(/(喜欢|偏好|爱喝|爱喝|习惯|一般要|以后都|记住我|我喝|我要.*(甜|冰|热|杯))/.test(t)){
      var pk = "口味", pv = "";
      if(/少糖|半糖|微糖|多糖|无糖|不加糖|正常糖|三分糖|五分糖|七分糖/.test(t)){
        pk = "甜度";
        pv = (t.match(/少糖|半糖|微糖|多糖|无糖|不加糖|正常糖|三分糖|五分糖|七分糖/)||[""])[0];
      }else if(/去冰|少冰|多冰|常温|热饮|冰的|冰饮|热的|加冰|不加冰|温的/.test(t)){
        pk = "温度";
        pv = (t.match(/去冰|少冰|多冰|常温|热饮|冰的|冰饮|热的|加冰|不加冰|温的/)||[""])[0];
      }else if(/大杯|中杯|小杯|超大杯/.test(t)){
        pk = "杯型";
        pv = (t.match(/大杯|中杯|小杯|超大杯/)||[""])[0];
      }else if(/咖啡|果汁|气泡水|碳酸|可乐|橙汁|茶|牛奶|豆浆|矿泉水/.test(t)){
        pk = "口味";
        pv = (t.match(/咖啡|果汁|气泡水|碳酸|可乐|橙汁|茶|牛奶|豆浆|矿泉水/)||[""])[0];
      }
      if(!pv){
        pv = cleanStuff(t.replace(/^(我|咱)/,"").replace(/(喜欢|偏好|爱喝|习惯|一般要|以后都|记住我)/g," ").trim());
      }
      if(pv && pv.length <= 16){
        DB.prefs.unshift({ key:pk, value:pv, from:"说话", time:now() });
        addLog("偏好", "记下偏好：" + pk + " = " + pv, "说话");
        save(); renderPrefs(); renderLogs();
        return "记下了 —— " + pk + "：" + pv + "。以后点单我按这个来。";
      }
    }

    /* 4. 取料 */
    slotNo = pickSlot(t);
    if(slotNo && /(取出|清空|倒掉|拿掉|去掉|不要了|撤|空)/.test(t)){
      var s1 = slotByNo(slotNo);
      var old1 = DB.slots[s1.k];
      DB.slots[s1.k] = "";
      addLog("取料", s1.no + " 取出" + (old1 ? "：" + old1 : "（本来就是空的）"), "说话");
      save(); renderSlots(); renderSlotEdit(); renderLogs();
      return old1 ? ("好，" + s1.no + " 里的「" + old1 + "」拿出来了，现在空了。") : (s1.no + " 本来就是空的。");
    }

    /* 5. 放料 */
    if(slotNo){
      var s2 = slotByNo(slotNo);
      var mv = t.match(/(?:加|放|装|倒|换成|换|来|要|弄)(.+)$/);
      var stuff = mv ? cleanStuff(mv[1]) : "";
      stuff = stuff.replace(/^(点|一杯|个|份)/, "");
      if(stuff && stuff.length <= 16){
        var old2 = DB.slots[s2.k];
        DB.slots[s2.k] = stuff;
        addLog("放料", s2.no + (old2 ? " 由「" + old2 + "」换成「" + stuff + "」" : " 放入「" + stuff + "」"), "说话");
        save(); renderSlots(); renderSlotEdit(); renderLogs();
        return old2 ? ("换好了，" + s2.no + " 现在是「" + stuff + "」。") : ("放好了，" + s2.no + " 现在装的是「" + stuff + "」。");
      }
      return s2.no + " 要放什么？你说「" + s2.no + "加可乐」这样就行。";
    }

    /* 6. 兜底 */
    return "这句我没听太明白。你可以试试：「1 号格子加可乐」「我不吃香菜」「我一般要少糖」「现在都放了啥」。";
  }

  function say(text){
    text = (text||"").trim();
    if(!text) return;
    pushChat("me", text);
    var reply;
    try{ reply = parse(text); }
    catch(e){ reply = "刚才没处理好，你换个说法再试一次。"; }
    pushChat("bot", reply);
    save(); renderChat();
  }

  /* ---------------- 交互绑定 ---------------- */
  function bindTabs(){
    var tabs = document.querySelectorAll(".tab");
    Array.prototype.forEach.call(tabs, function(b){
      b.addEventListener("click", function(){
        Array.prototype.forEach.call(tabs, function(x){ x.classList.remove("active"); });
        Array.prototype.forEach.call(document.querySelectorAll(".panel"), function(p){ p.classList.remove("active"); });
        b.classList.add("active");
        var p = document.getElementById(b.getAttribute("data-tab"));
        if(p) p.classList.add("active");
      });
    });
  }

  function bindTalk(){
    var input = document.getElementById("say");
    var send = document.getElementById("send");
    function go(){
      if(!input) return;
      var v = input.value;
      input.value = "";
      say(v);
    }
    if(send) send.addEventListener("click", go);
    if(input) input.addEventListener("keydown", function(e){
      if(e.key === "Enter"){ e.preventDefault(); go(); }
    });

    var chips = ["1 号格子加可乐", "我不吃香菜", "我一般要少糖", "现在都放了啥"];
    var cbox = document.getElementById("chips");
    if(cbox){
      cbox.innerHTML = chips.map(function(c){
        return '<button class="chip" type="button" data-chip="'+esc(c)+'">'+esc(c)+'</button>';
      }).join("");
      cbox.addEventListener("click", function(e){
        var b = e.target.closest("[data-chip]");
        if(b) say(b.getAttribute("data-chip"));
      });
    }

    var mic = document.getElementById("mic");
    if(mic){
      mic.addEventListener("click", function(){
        var SR = window.SpeechRecognition || window.webkitSpeechRecognition;
        if(!SR){
          pushChat("bot", "这个浏览器不支持说话输入。打字也一样管用，你说「1 号格子加可乐」就行。");
          save(); renderChat();
          return;
        }
        try{
          var r = new SR();
          r.lang = "zh-CN";
          r.onresult = function(ev){
            var txt = ev.results[0][0].transcript;
            say(txt);
          };
          r.onerror = function(){
            pushChat("bot", "没听清，你打字吧，一样管用。");
            save(); renderChat();
          };
          r.start();
          pushChat("bot", "在听，你说……");
          save(); renderChat();
        }catch(e){
          pushChat("bot", "这个浏览器用不了说话，打字就行。");
          save(); renderChat();
        }
      });
    }
  }

  function bindPrefs(){
    var add = document.getElementById("pref-add");
    if(add) add.addEventListener("click", function(){
      var k = document.getElementById("pref-key").value;
      var v = document.getElementById("pref-val").value.trim();
      if(!v){ return; }
      DB.prefs.unshift({ key:k, value:v, from:"手动", time:now() });
      addLog("偏好", "记下偏好：" + k + " = " + v, "手动");
      document.getElementById("pref-val").value = "";
      save(); renderPrefs(); renderLogs();
    });
    document.addEventListener("click", function(e){
      var ed = e.target.closest("[data-pref-edit]");
      var dl = e.target.closest("[data-pref-del]");
      if(ed){
        var i1 = parseInt(ed.getAttribute("data-pref-edit"),10);
        var p1 = DB.prefs[i1];
        if(!p1) return;
        var nv = window.prompt("改成什么？", p1.value);
        if(nv && nv.trim()){
          addLog("偏好", "偏好改动：" + p1.key + " 由「" + p1.value + "」改为「" + nv.trim() + "」", "手动");
          p1.value = nv.trim(); p1.time = now();
          save(); renderPrefs(); renderLogs();
        }
      }
      if(dl){
        var i2 = parseInt(dl.getAttribute("data-pref-del"),10);
        var p2 = DB.prefs[i2];
        if(!p2) return;
        if(!window.confirm("删掉这条偏好：" + p2.key + " = " + p2.value + "？")) return;
        addLog("偏好", "删掉偏好：" + p2.key + " = " + p2.value, "手动");
        DB.prefs.splice(i2,1);
        save(); renderPrefs(); renderLogs();
      }
    });
  }

  function bindBans(){
    var add = document.getElementById("ban-add");
    if(add) add.addEventListener("click", function(){
      var k = document.getElementById("ban-kind").value;
      var v = document.getElementById("ban-val").value.trim();
      if(!v){ return; }
      DB.bans.unshift({ kind:k, value:v, from:"手动", time:now() });
      addLog("忌口", "记下忌口：" + v + "（" + k + "）", "手动");
      document.getElementById("ban-val").value = "";
      save(); renderBans(); renderLogs();
    });
    document.addEventListener("click", function(e){
      var ed = e.target.closest("[data-ban-edit]");
      var dl = e.target.closest("[data-ban-del]");
      if(ed){
        var i1 = parseInt(ed.getAttribute("data-ban-edit"),10);
        var b1 = DB.bans[i1];
        if(!b1) return;
        var nv = window.prompt("改成什么？", b1.value);
        if(nv && nv.trim()){
          addLog("忌口", "忌口改动：由「" + b1.value + "」改为「" + nv.trim() + "」", "手动");
          b1.value = nv.trim(); b1.time = now();
          save(); renderBans(); renderLogs();
        }
      }
      if(dl){
        var i2 = parseInt(dl.getAttribute("data-ban-del"),10);
        var b2 = DB.bans[i2];
        if(!b2) return;
        if(!window.confirm("删掉这条忌口：" + b2.value + "？")) return;
        addLog("忌口", "删掉忌口：" + b2.value, "手动");
        DB.bans.splice(i2,1);
        save(); renderBans(); renderLogs();
      }
    });
  }

  function bindBrew(){
    document.addEventListener("click", function(e){
      var b = e.target.closest("[data-brew]");
      if(b){ brew(parseInt(b.getAttribute("data-brew"),10)); return; }
      var a = e.target.closest("[data-again]");
      if(a){
        var nm = a.getAttribute("data-again");
        for(var i=0;i<RECIPES.length;i++){
          if(RECIPES[i].name === nm){ brew(i); return; }
        }
      }
    });
  }

  function bindBack(){
    document.addEventListener("click", function(e){
      var sv = e.target.closest("[data-save]");
      var cl = e.target.closest("[data-clear]");
      if(sv){
        var k1 = sv.getAttribute("data-save");
        var inp = document.querySelector('[data-slot="'+k1+'"]');
        var s1 = null;
        SLOTS.forEach(function(s){ if(s.k === k1) s1 = s; });
        if(!inp || !s1) return;
        var nv = inp.value.trim();
        var old = DB.slots[k1] || "";
        if(nv === old) return;
        DB.slots[k1] = nv;
        addLog(nv ? "放料" : "取料",
          nv ? (s1.no + (old ? " 由「"+old+"」换成「"+nv+"」" : " 放入「"+nv+"」"))
             : (s1.no + " 取出" + (old ? "："+old : "（本来就是空的）")),
          "手动");
        save(); renderSlots(); renderSlotEdit(); renderLogs();
      }
      if(cl){
        var k2 = cl.getAttribute("data-clear");
        var s2 = null;
        SLOTS.forEach(function(s){ if(s.k === k2) s2 = s; });
        if(!s2) return;
        var old2 = DB.slots[k2] || "";
        if(!old2) return;
        DB.slots[k2] = "";
        addLog("取料", s2.no + " 取出：" + old2, "手动");
        save(); renderSlots(); renderSlotEdit(); renderLogs();
      }
    });

    var lc = document.getElementById("log-clear");
    if(lc) lc.addEventListener("click", function(){
      if(!DB.logs.length) return;
      if(!window.confirm("清空全部改动记录？清了就找不回来了。")) return;
      DB.logs = [];
      save(); renderLogs();
    });
  }

  /* ---------------- 四格基础设置 ---------------- */
  var CAT_KEY = "dm_slot_catalog_v1";
  var UNKNOWN = "未知 · 待定";
  var DEFAULT_CAT = ["东方树叶", "水溶 C100", "橙汁", "牛奶", "果蔬汁"];
  function catalog(){
    try{
      var a = JSON.parse(localStorage.getItem(CAT_KEY) || "[]");
      if(Array.isArray(a) && a.length) return a;
    }catch(e){ /* 读不到就用默认 */ }
    return DEFAULT_CAT.slice();
  }
  function saveCatalog(a){
    try{ localStorage.setItem(CAT_KEY, JSON.stringify(a)); }catch(e){ /* 写不进就算了 */ }
  }
  function slotNo(k){
    var s = null;
    SLOTS.forEach(function(x){ if(x.k === k) s = x; });
    return s ? (s.no + " · " + s.pos) : k;
  }
  function renderBase(){
    var box = document.getElementById("base-list");
    if(!box) return;
    var cat = catalog();
    box.innerHTML = SLOTS.map(function(s){
      var v = DB.slots[s.k] || "";
      var list = cat.slice();
      if(v && v !== UNKNOWN && list.indexOf(v) < 0) list.unshift(v);
      var opts = ['<option value="">— 未定 —</option>'];
      list.forEach(function(n){
        opts.push('<option value="'+esc(n)+'"'+(v === n ? " selected" : "")+'>'+esc(n)+'</option>');
      });
      opts.push('<option value="'+esc(UNKNOWN)+'"'+(v === UNKNOWN ? " selected" : "")+'>'+esc(UNKNOWN)+'</option>');
      return '<div class="row">'+
        '<div class="main"><div class="t">'+esc(s.no)+' · '+esc(s.pos)+'</div>'+
        '<div class="d">格子坐标 '+esc(s.k)+' · 基础装什么</div></div>'+
        '<select class="base-sel" data-base="'+esc(s.k)+'">'+opts.join("")+'</select>'+
      '</div>';
    }).join("");
    var cbox = document.getElementById("cat-chips");
    if(cbox){
      cbox.innerHTML = '<span class="cat-hint">品类清单（点 ✕ 删掉）：</span>' + cat.map(function(n){
        return '<button class="chip" type="button" data-catdel="'+esc(n)+'">'+esc(n)+' ✕</button>';
      }).join("");
    }
  }
  function bindBase(){
    var box = document.getElementById("base-list");
    if(box){
      box.addEventListener("change", function(e){
        var sel = e.target.closest("[data-base]");
        if(!sel) return;
        var k = sel.getAttribute("data-base");
        var nv = sel.value;
        var old = DB.slots[k] || "";
        if(nv === old) return;
        DB.slots[k] = nv;
        addLog("基础设置", slotNo(k) + (nv ? " 基础定为「"+nv+"」" : " 基础清空") + (old ? "（原："+old+"）" : ""), "手动");
        save(); renderSlots(); renderRaw(); renderBase(); renderLogs();
      });
    }
    var add = document.getElementById("cat-add");
    var inp = document.getElementById("cat-new");
    if(add && inp){
      add.addEventListener("click", function(){
        var v = (inp.value || "").trim();
        if(!v){ window.alert("先写个品类名，比如：果蔬汁"); return; }
        var a = catalog();
        if(a.indexOf(v) < 0){ a.push(v); saveCatalog(a); addLog("基础设置", "品类清单新增：" + v, "手动"); renderLogs(); }
        inp.value = "";
        renderBase();
      });
    }
    var cbox = document.getElementById("cat-chips");
    if(cbox){
      cbox.addEventListener("click", function(e){
        var b = e.target.closest("[data-catdel]");
        if(!b) return;
        var n = b.getAttribute("data-catdel");
        if(!window.confirm("从品类清单里删掉「" + n + "」？（已经装进格子的不受影响）")) return;
        saveCatalog(catalog().filter(function(x){ return x !== n; }));
        addLog("基础设置", "品类清单删除：" + n, "手动");
        renderBase(); renderLogs();
      });
    }
    var rst = document.getElementById("base-reset");
    if(rst){
      rst.addEventListener("click", function(){
        if(!window.confirm("把四个格子的基础设置全部清空？")) return;
        SLOTS.forEach(function(s){ DB.slots[s.k] = ""; });
        addLog("基础设置", "四格基础全部清空", "手动");
        save(); renderSlots(); renderRaw(); renderBase(); renderLogs();
      });
    }
  }

  function bindData(){
    var add = document.getElementById("user-add");
    if(add) add.addEventListener("click", function(){
      var acc = (document.getElementById("user-acc").value || "").trim();
      var voice = (document.getElementById("user-voice").value || "").trim();
      var nm = (document.getElementById("user-name").value || "").trim();
      if(!acc && !voice){ window.alert("账号和声纹至少填一个。"); return; }
      var id = nextUserId();
      DB.users.push({ id:id, acc:acc, voice:voice, name:nm, created:now(), createdTs:Date.now() });
      if(!DB.curUser) DB.curUser = id;
      addLog("用户", "建用户 " + id + (nm ? "（"+nm+"）" : "") + (acc ? " · 账号 "+acc : "") + (voice ? " · 声纹 "+voice : ""), "手动");
      document.getElementById("user-acc").value = "";
      document.getElementById("user-voice").value = "";
      document.getElementById("user-name").value = "";
      save(); renderUsers(); renderGroup(); renderLogs();
    });

    var oadd = document.getElementById("order-add");
    if(oadd) oadd.addEventListener("click", function(){
      var uid = document.getElementById("order-user").value;
      var drink = (document.getElementById("order-drink").value || "").trim();
      var detail = (document.getElementById("order-detail").value || "").trim();
      if(!uid){ window.alert("先在「用户」里建一个用户。"); return; }
      if(!drink && !detail){ window.alert("AI 配比内容或点单内容，至少填一个。"); return; }
      DB.orders.unshift({ user:uid, drink:drink || "—", detail:detail, time:now(), ts:Date.now(), from:"手录" });
      if(DB.orders.length > 500) DB.orders = DB.orders.slice(0,500);
      addLog("点单", "记一单：" + userName(uid) + " · " + (drink || detail), "手录");
      document.getElementById("order-drink").value = "";
      document.getElementById("order-detail").value = "";
      save(); renderOrders(); renderGroup(); renderLogs();
    });

    var gm = document.getElementById("group-month");
    if(gm) gm.addEventListener("change", function(){ renderGroup(); });

    document.addEventListener("click", function(e){
      var st = e.target.closest("[data-userset]");
      if(st){
        DB.curUser = st.getAttribute("data-userset");
        addLog("用户", "当前用户切到 " + userName(DB.curUser), "手动");
        save(); renderUsers(); renderLogs();
        return;
      }
      var ud = e.target.closest("[data-userdel]");
      if(ud){
        var id = ud.getAttribute("data-userdel");
        if(!window.confirm("删掉用户 " + id + "？点单记录会留着。")) return;
        DB.users = DB.users.filter(function(u){ return u.id !== id; });
        if(DB.curUser === id) DB.curUser = DB.users.length ? DB.users[0].id : "";
        addLog("用户", "删掉用户 " + id, "手动");
        save(); renderUsers(); renderGroup(); renderLogs();
        return;
      }
      var cs = e.target.closest("[data-capsave]");
      if(cs){
        var nm2 = cs.getAttribute("data-capsave");
        var inp = document.querySelector('[data-cap="'+nm2+'"]');
        var v = inp ? Number(inp.value) : 0;
        if(isNaN(v) || v < 0) v = 0;
        DB.caps[nm2] = v;
        addLog("原料", "原料容量：" + nm2 + " 设为 " + v + " 杯", "手动");
        save(); renderRaw(); renderLogs();
      }
    });
  }

  try{
    load();
    bindTabs();
    bindTalk();
    bindPrefs();
    bindBans();
    bindBack();
    bindBrew();
    bindBase();
    renderSlots();
    renderBase();
    renderSlotEdit();
    renderPrefs();
    renderBans();
    renderLogs();
    renderChat();
    renderRecipes();
    renderHistory();
    renderRaw();
    bindData();
    renderUsers();
    renderGroup();
    renderOrders();
  }catch(e){
    /* 单块渲染异常不影响其它区块 */
  }

  /* 用户端小程序那边改了四格、出了杯，这页立刻跟着变 */
  window.addEventListener("storage", function(e){
    if(!e) return;
    if(e.key === SHARED_KEY || e.key === USER_HIST_KEY){
      load(); renderSlots(); renderSlotEdit(); renderHistory(); renderRaw(); renderOrders(); renderGroup(); renderBase();
    }
  });
})();
