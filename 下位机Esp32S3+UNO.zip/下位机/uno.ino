
#include <SoftwareSerial.h>

SoftwareSerial mySerial(A0,A1);
String item;

void x_3() {
  while (x3() == 1) {
    if (x3() == 0) {
      _E5_85_A8_E5_81_9C();
      break;

    }
    x_E4_B8_8A();
  }
  _E5_85_A8_E5_81_9C();
}

void x_2() {
  while (x2() == 1) {
    if (x2() == 0) {
      _E5_85_A8_E5_81_9C();
      break;

    }
    x_E4_B8_8A();
  }
  _E5_85_A8_E5_81_9C();
}

void y_E4_B8_8A() {
  digitalWrite(9,LOW);
  digitalWrite(10,LOW);
  digitalWrite(11,HIGH);
  digitalWrite(12,LOW);
}

void x_E4_B8_8A() {
  digitalWrite(9,LOW);
  digitalWrite(10,LOW);
  digitalWrite(11,LOW);
  digitalWrite(12,HIGH);
}

int y1() {
  return digitalRead(2);
}

void y_1() {
  while (y1() == 1) {
    if (y1() == 0) {
      _E5_85_A8_E5_81_9C();
      break;

    }
    y_E4_B8_8B();
  }
  _E5_85_A8_E5_81_9C();
}

void x_4() {
  while (x4() == 1) {
    if (x4() == 0) {
      _E5_85_A8_E5_81_9C();
      break;

    }
    x_E4_B8_8A();
  }
  _E5_85_A8_E5_81_9C();
}

void x_E4_B8_8B() {
  digitalWrite(9,LOW);
  digitalWrite(10,HIGH);
  digitalWrite(11,LOW);
  digitalWrite(12,LOW);
}

void y_3() {
  while (y3() == 1) {
    if (y3() == 0) {
      _E5_85_A8_E5_81_9C();
      break;

    }
    y_E4_B8_8A();
  }
  _E5_85_A8_E5_81_9C();
}

void y_2() {
  while (y2() == 1) {
    if (y2() == 0) {
      _E5_85_A8_E5_81_9C();
      break;

    }
    y_E4_B8_8A();
  }
  _E5_85_A8_E5_81_9C();
}

void y_E4_B8_8B() {
  digitalWrite(12,LOW);
  digitalWrite(11,LOW);
  digitalWrite(10,LOW);
  digitalWrite(9,HIGH);
}

int x4() {
  return digitalRead(8);
}

int y2() {
  return digitalRead(3);
}

void _E5_85_A8_E5_81_9C() {
  digitalWrite(9,LOW);
  digitalWrite(10,LOW);
  digitalWrite(11,LOW);
  digitalWrite(12,LOW);
}

int x2() {
  return digitalRead(6);
}

void x_1() {
  while (x1() == 1) {
    if (x1() == 0) {
      _E5_85_A8_E5_81_9C();
      break;

    }
    x_E4_B8_8B();
  }
  _E5_85_A8_E5_81_9C();
}

int x1() {
  return digitalRead(5);
}

int x3() {
  return digitalRead(7);
}

int y3() {
  return digitalRead(4);
}

void setup(){
  Serial.begin(9600);
  mySerial.begin(9600);
  item = "";
  pinMode(9, OUTPUT);
  pinMode(10, OUTPUT);
  pinMode(11, OUTPUT);
  pinMode(12, OUTPUT);
  pinMode(2, INPUT_PULLUP);
  pinMode(3, INPUT_PULLUP);
  pinMode(4, INPUT_PULLUP);
  pinMode(5, INPUT_PULLUP);
  pinMode(6, INPUT_PULLUP);
  pinMode(7, INPUT_PULLUP);
  pinMode(8, INPUT_PULLUP);
  digitalWrite(9,LOW);
  digitalWrite(10,LOW);
  digitalWrite(11,LOW);
  digitalWrite(12,LOW);
  y_1();
  x_1();
}

void loop(){
  if (mySerial.available()) {
    item = mySerial.readString();
    if (String(item).toInt() == 1) {
      x_4();
      x_1();
      y_3();
      y_1();

    }
    if (String(item).toInt() == 2) {
      x_3();
      x_1();
      y_3();
      y_1();

    }
    if (String(item).toInt() == 3) {
      x_4();
      x_1();
      y_2();
      y_1();

    }
    if (String(item).toInt() == 4) {
      x_3();
      x_1();
      y_2();
      y_1();

    }
    if (String(item).toInt() == 0) {
      x_2();

    }
    mySerial.print("over");

  }

}