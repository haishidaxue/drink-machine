
#include <WiFi.h>
#include <HardwareSerial.h>
#include <PubSubClient.h>
WiFiClient mqtt_wifiClient;

PubSubClient mqtt_client(mqtt_wifiClient);
String mqtt_subTopic = "mixly/data";
void mqtt_callback(char* topic, byte* payload, unsigned int length) {
  String data = "";
  for (unsigned int i = 0; i < length; i++) {
    data += (char)payload[i];
  }
  _return(data);
}

void _air() {
  digitalWrite(2,HIGH);
}

void beng_start() {
  digitalWrite(9,HIGH);
}

void fa_stop() {
  digitalWrite(2,LOW);
  digitalWrite(5,LOW);
  digitalWrite(4,LOW);
  digitalWrite(8,LOW);
  digitalWrite(7,LOW);
  digitalWrite(15,LOW);
  digitalWrite(13,HIGH);
}

void _waterc() {
  digitalWrite(5,HIGH);
}

void _tea() {
  digitalWrite(4,HIGH);
}

void _orange() {
  digitalWrite(8,HIGH);
}

void cup_down() {
  digitalWrite(13,LOW);
  delay(1000);
  digitalWrite(13,HIGH);
}

void _milk() {
  digitalWrite(7,HIGH);
}

void _water() {
  digitalWrite(6,HIGH);
}

void beng_stop() {
  digitalWrite(9,LOW);
}

String json_extract(String json, String key) {
  String search = "\"" + key + "\":";
  int idx = json.indexOf(search);
  if (idx < 0) return "";
  idx += search.length();
  while (idx < json.length() && (json[idx] == ' ' || json[idx] == '\t')) idx++;
  if (idx >= json.length()) return "";
  if (json[idx] == '\"') {
    idx++;
    String result = "";
    while (idx < json.length() && json[idx] != '\"') {
      if (json[idx] == '\\' && idx + 1 < json.length()) {
        char next = json[idx + 1];
        if (next == 'n') result += '\n';
        else if (next == 't') result += '\t';
        else if (next == 'r') result += '\r';
        else if (next == '\"') result += '\"';
        else if (next == '\\') result += '\\';
        else result += next;
        idx += 2;
      } else {
        result += json[idx];
        idx++;
      }
    }
    return result;
  } else {
    String result = "";
    while (idx < json.length() && json[idx] != ',' && json[idx] != '}' && json[idx] != ']') {
      result += json[idx];
      idx++;
    }
    result.trim();
    return result;
  }
}

void _return(String data) {
  Serial.println(data);
  int _ = 10000;
  int cup = String(json_extract(data, "cup")).toInt();
  int c = 0;
  int milk = 0;
  int orange = 0;
  int tea = 0;
  for (int i = (1); i <= (cup); i = i + (1)) {
    cup_down();
    delay(3000);
    Serial1.println(0);
    wait_over();
    c = String(json_extract(data, String(i) + String("c"))).toInt();
    milk = String(json_extract(data, String(i) + String("milk"))).toInt();
    orange = String(json_extract(data, String(i) + String("orange"))).toInt();
    tea = String(json_extract(data, String(i) + String("tea"))).toInt();
    Serial.println(c);
    Serial.println(milk);
    Serial.println(orange);
    Serial.println(tea);
    Serial.println("**********************************");
    if (orange + (milk + (c + tea)) == 4) {
      beng_start();
      delay(2000);
      _waterc();
      delay((_ * c));
      fa_stop();
      _tea();
      delay((_ * tea));
      fa_stop();
      _milk();
      delay((_ * milk));
      fa_stop();
      _orange();
      delay((_ * orange));
      fa_stop();
      beng_stop();
      Serial1.println(i);
      wait_over();

    } else {
      break;

    }
  }
}

void wait_over() {
  String l = "";
  while (true) {
    if (Serial1.available()) {
      l = Serial1.readString();
      if (l == "over") {
        break;

      }

    }
  }
}

void setup(){
  WiFi.begin("222", "88888888");
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  Serial.println("Local IP:");
  Serial.print(WiFi.localIP());

  Serial1.begin(9600,SERIAL_8N1,46,47);
  Serial.begin(115200);
    for (int i = 0; i < 100 && WiFi.status() != WL_CONNECTED; i++) {
    delay(200);
  }
  Serial.print("WIFI:"); Serial.println(WiFi.status());
  Serial.print("IP:"); Serial.println(WiFi.localIP());
  Serial.print("GW:"); Serial.println(WiFi.gatewayIP());
  Serial.print("NET:");
  Serial.println(mqtt_wifiClient.connect("223.5.5.5", 80) ? "OK" : "FAIL");
  mqtt_wifiClient.stop();
  mqtt_client.setServer("broker-cn.emqx.io", 1883);
  mqtt_client.setCallback(mqtt_callback);
  mqtt_client.setBufferSize(2048);
  if (mqtt_client.connect("esp32s3")) {
    mqtt_client.subscribe(mqtt_subTopic.c_str());
    Serial.println("MQTT:OK");
  } else {
    Serial.print("MQTT:FAIL "); Serial.println(mqtt_client.state());
  }

  beng_stop();
  fa_stop();
  pinMode(2, OUTPUT);
  pinMode(9, OUTPUT);
  pinMode(5, OUTPUT);
  pinMode(4, OUTPUT);
  pinMode(8, OUTPUT);
  pinMode(7, OUTPUT);
  pinMode(15, OUTPUT);
  pinMode(13, OUTPUT);
  pinMode(6, OUTPUT);
}

void loop(){
    if (WiFi.status() == WL_CONNECTED && !mqtt_client.connected()) {
    static unsigned long mqtt_retryTimer = 0;
    if (millis() - mqtt_retryTimer > 1000) {
      mqtt_retryTimer = millis();
      if (mqtt_client.connect("esp32s3")) {
        mqtt_client.subscribe(mqtt_subTopic.c_str());
        Serial.println("MQTT:OK");
      }
    }
  }
  mqtt_client.loop();

}